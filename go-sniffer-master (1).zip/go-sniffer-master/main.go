package main

import (
	"github.com/40t/go-sniffer/core"
)

func main() {
	core := core.New()
	core.Run()
}